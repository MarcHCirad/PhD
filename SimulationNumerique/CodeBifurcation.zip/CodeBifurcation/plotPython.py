import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import pathlib


def plotDiscreteBifurcationFile(inputFileName,
                saveFig = True, saveFileName="",
                transformData = lambda x:x,
                dicEqColor = {}, xlabel = "", ylabel="",
                tickText = [],
                toPlot=False, fontsize = 12):

    if saveFileName == "":
        saveFileName = inputFileName[0:-4] + ".png"

    data = pd.read_csv(inputFileName)
    data = data.to_numpy()
    listParamX = np.float64(data[0, 1:])
    listParamY = np.float64(data[1:, 0])
    color = np.array(data[1:, 1:], dtype=str)
    color = transformData(color)

    legendSize = 3
    myTickVals = [k for k in range(0,legendSize)]
    myTickBoundaries = [(2*k-1)/2 for k in range(0,legendSize+1)]

    if len(tickText) == 0:
        tickText = ["{0}".format(k) for k in range(legendSize)]

    fig, ax = plt.subplots(1)

    listColor = ["royalblue", "firebrick", "darkorange"]
    counter = 0
    myColors = []

    for k in range(0, legendSize):
        if k in dicEqColor.keys():
            myColors.append(dicEqColor[k])
        else:
            myColors.append(listColor[counter])
            counter += 1
            print(k, " has no colour")

    print(counter, " colors were not defined")
    myColormap = ListedColormap(myColors)

    im = ax.pcolormesh(listParamX, listParamY, color, cmap=myColormap, vmin=myTickBoundaries[0], vmax=myTickBoundaries[-1])
    # colorhatch = np.ma.masked_less(color, 3)

    ax.contourf(listParamX, listParamY, color, colors='none')
    cbar = fig.colorbar(im, boundaries = myTickBoundaries, values=myTickVals, drawedges = True)
    cbar.set_ticks(myTickVals)
    cbar.set_ticklabels(tickText, fontsize=fontsize)
    ax.set_xlabel(xlabel, fontsize=fontsize)
    ax.set_ylabel(ylabel, fontsize=fontsize)
    ax.tick_params(labelsize=fontsize)

    if toPlot:
        plt.show()

    if saveFig:
        fig.savefig(saveFileName)

    return fig, ax

def eqNamestoNbr(tab):
    rslt = np.zeros_like(tab, dtype=float)
    ncol, nrow = rslt.shape
    for indCol in range(ncol):
        for indRow in range(nrow):
            val = tab[indCol, indRow]
            if val == "HFW":
                rsltVal = 1
            elif val == "LC":
                rsltVal = 2
            else: ## NaN case
                rsltVal = 0
            rslt[indCol, indRow] = rsltVal
    return rslt

pathWD = str(pathlib.Path(__file__).parent.resolve())

input = pathWD + "/Diagram.csv"


myFig, myAx = plotDiscreteBifurcationFile(
                    input, ylabel="$\\alpha$", xlabel="$\\lambda_{F}$",
                    saveFig = False, toPlot=False, fontsize=20
                    , tickText=["$EE^{H}$ GAS", "$EE^{HF_W}$ GAS", "$EE^{HF_W}$ \n Limit Cycle"]
                    , dicEqColor={0 : "#5e4c5f", 1 : "#1a80bb", 2 : "#ea801c"}
                    , transformData=eqNamestoNbr
                    )

# inputLambdaMin = pathWD + "/Diagram1DMin.csv"
# data = pd.read_csv(inputLambdaMin, low_memory=False)
# data = data.to_numpy()
# listAlpha = np.float64(data[1:, 0])
# listLambdaMin = np.float64(data[1:, 1])
# line, = myAx.plot(listLambdaMin[0:-1:10], listAlpha[0:-1:10], '--', linewidth = 3,
#            color = "black")
# line.set_label("$\\lambda_{F, I=0}^{Min}(\\alpha)$")
# myAx.legend(fontsize=20)


inputLambdaMax = pathWD + "/Diagram1DMax.csv"
data = pd.read_csv(inputLambdaMax, low_memory=False)
data = data.to_numpy()
listAlpha = np.float64(data[1:, 0])
listLambdaMax = np.float64(data[1:, 1])
line, = myAx.plot(listLambdaMax[0:-1:10], listAlpha[0:-1:10], '-.', linewidth = 3,
           color = "black")
line.set_label("$\\lambda_{F, I>0}^{Max}(\\alpha)$")
myAx.legend(fontsize=20)
# myAx.set_xlim((0.0, 0.05))


plt.show(block = True)



