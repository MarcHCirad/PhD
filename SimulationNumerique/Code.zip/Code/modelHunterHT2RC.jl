struct modelHunterHT2 <: mathematicalModel
    variablesNames::Vector{String}

    rF::Float64
    KF::Float64
    alpha::Float64
    beta::Float64
    lambdaFWH::Float64
    theta::Float64
    e::Float64
    I::Float64
    muD::Float64
    fD::Float64
    mD::Float64
    mW::Float64

    m::Float64
        
    function modelHunterHT2(modelParam::Dict{String, Any})

        rF, lambdaFWH, KF = modelParam["rF"], modelParam["lambdaFWH"], modelParam["KF"]
        alpha, beta = modelParam["alpha"], modelParam["beta"]
        theta, e, I = modelParam["theta"], modelParam["e"], modelParam["I"]
        muD, fD, mD, mW = modelParam["muD"], modelParam["fD"], modelParam["mD"], modelParam["mW"]
        variablesNames = ["H_D2d", "F_W2d", "H_W2d", "H_D", "F_W", "H_W"]
        m  = mD / mW

        @assert(alpha < 1)
        bound = 4 * (muD - fD) / (m * e * rF * KF * (1-alpha)^2)
        @assert (bound > beta) "bound for beta is $bound"

        new(variablesNames, rF, KF, alpha, beta, lambdaFWH, theta, e, I, muD, fD, mD, mW, m)
    end
end

function equationModel(model::modelHunterHT2, variables::Vector{Float64})
    """
    Return the right hand side of the model
    """
    HD2d, FW2d, HW2d = variables[1], variables[2], variables[3]
    dHD2d = (model.I + model.e * model.lambdaFWH * FW2d / (1 + model.theta * model.lambdaFWH * FW2d) * model.m * HD2d + 
        (model.fD - model.muD) * HD2d)
    dFW2d = ((1 - model.alpha) * (1 + model.beta * model.m * HD2d) * model.rF * (1 - FW2d / (model.KF * (1 - model.alpha))) * FW2d -
            model.lambdaFWH * FW2d / (1 + model.theta * model.lambdaFWH * FW2d) * model.m * HD2d)

    HD, FW, HW = variables[4], variables[5], variables[6]
    dHD = (model.I + model.e * model.lambdaFWH * FW / (1 + model.theta * model.lambdaFWH * FW) * HW + 
        (model.fD- model.muD) * HD - model.mD * HD + model.mW * HW)
    dFW = ((1 - model.alpha) * (1 + model.beta * HW) * model.rF * (1 - FW / (model.KF * (1 - model.alpha))) * FW -
            model.lambdaFWH * FW / (1 + model.theta * model.lambdaFWH * FW) * HW)
    dHW = model.mD * HD - model.mW * HW

    return [dHD2d, dFW2d, model.m * dHD2d, dHD, dFW, dHW]
end

function computeBetaMax(model::modelHunterHT2 ; alpha = -1.0)
    if alpha < 0
        alpha = model.alpha
    end
    betaMax = 4 * (model.muD - model.fD) / (model.m * model.e * model.rF * model.KF * (1-alpha)^2)
    return betaMax
end

function thresholdN(model::modelHunterHT2)
    """
    When I = 0 : If < 1, EE^F is GAS ; if > 1 EE^HFW exists
    When I > 0 : If < 1, EE^H is GAS ; when > 1 EE^HFW exists ; EE^HFW may exist even if <= 1
    """
    if model.I == 0
        NI = (model.lambdaFWH * model.KF * (1 - model.alpha)) * 
        (model.m * model.e - model.theta * (model.muD - model.fD)) / (model.muD - model.fD)
    else
        NI = model.rF * (1-model.alpha) * 
            ((model.muD - model.fD) / (model.m * model.I) + model.beta) / model.lambdaFWH
    end
    return NI
end

function computeLambdaMinI0(model::modelHunterHT2 ; alpha = -1.0, e = -1.0, mW = -1.0)
    """
    When I = 0, compute lambda^min such that lambda > lambda^min iff EE^HFW exists
    """
    @assert model.I == 0
    if alpha < 0
        alpha = model.alpha
    end
    if e < 0
        e = model.e
    end
    if mW < 0
        mW = model.mW
    end

    m = model.mD / mW
    lambdaMin = (model.muD - model.fD) / ((1-alpha)*model.KF * (m * model.e - model.theta * (model.muD - model.fD)))
    return lambdaMin
end

function computelambdaMaxI0(model::modelHunterHT2)
    """
    When I = 0, compute lambda^max such that lambda < lambda^max iff EE^HFW is AS
    """
    if model.theta > 0
        num = (model.m * model.e + model.theta * (model.muD - model.fD))
        den = (model.m * model.e - model.theta * (model.muD - model.fD))
        return num / den / (model.KF * (1-model.alpha) * model.theta)
    else
        return Inf64
    end
end

function printAllCharacteristicValues(model::modelHunterHT2)
    betaMinMax = computeBetaMax(model ; alpha = 0)
    betaMax = computeBetaMax(model)

    println("Beta max pour alpha = 0 : ", betaMinMax)
    println("Beta max pour valeur de alpha donnée : ", betaMax)

    if model.I == 0
        lambdaMin = computeLambdaMinI0(model)
        println("Cas I = 0 ; lambdaMin = ", lambdaMin)
        lambdaMax = computelambdaMaxI0(model)
        println("Cas I = 0 ; lambdaMax = ", lambdaMax)
    end

    # if model.I > 0
    #     lambdaMaxMax = computeLambdaMax(model; alpha = 0)
    #     lambdaMax = computeLambdaMax(model)
    #     println("Cas I > 0 ; lambdaMax pour alpha = 0 : ", lambdaMaxMax)
    #     println("Cas I > 0 ; lambdaMax pour alpha donné : ", lambdaMax)
    # end
end


function equilibriumFW(model::modelHunterHT2)
    """
    When I == 0 ;
    return eq EE^F
    """
    return [0, model.KF * (1 - model.alpha), 0]
end

function equilibriumH(model::modelHunterHT2)
    """
    When I > 0 ;
    return eq EE^H
    """
    HD = model.I / (model.muD - model.fD)
    return [HD, 0, model.m * HD]
end

function equilibriumHFW(model::modelHunterHT2)
    """
    For I >= 0
    Compute the values of EE^HFW
    Rise a warning if negatif (threshold not respected)
    """
    if model.I == 0
        if thresholdN(model) > 1

            Feq = (model.muD - model.fD) / ((model.m * model.e - model.theta * (model.muD - model.fD ))* model.lambdaFWH)
            
            Heq = (1 - model.alpha) * model.rF * (1 - Feq / (model.KF * (1 - model.alpha)))
            Heq = Heq / (model.m * (model.lambdaFWH - model.beta * (1 - model.alpha) * model.rF + 
                        model.beta * model.rF * Feq / model.KF))
            eq = [Heq, Feq, model.m * Heq]
        else
            @warn "Equilibrium EE^HFW computed while it does not exists ; infinite values return "
            Feq, Heq = Inf64, Inf64
            eq = [Heq, Feq, model.m * Heq]
        end
    else
        numA = (model.e * model.m - model.theta * (model.muD - model.fD + model.beta * model.m * model.I))
        A = model.rF / model.KF * numA
        B = -((1 - model.alpha) * model.rF * numA  + 
            (model.muD - model.fD + model.beta * model.m * model.I) * model.rF / (model.lambdaFWH * model.KF))
        C = ((model.muD - model.fD + model.m * model.beta * model.I) * (1 - model.alpha) * model.rF / model.lambdaFWH - 
                model.m * model.I)

        NI = thresholdN(model)
        Delta = B^2 - 4 *A *C

        if NI > 1
            if numA < 0
                Feq = -B / (2*A) + sqrt(Delta) / (2*A)
            else
                Feq = -B / (2*A) - sqrt(Delta) / (2*A)
            end
            Heq = (1 - model.alpha) * model.rF * (1 - Feq / (model.KF * (1 - model.alpha)))
            Heq = Heq / (model.m * (model.lambdaFWH - model.beta * (1 - model.alpha) * model.rF + 
                    model.beta * model.rF * Feq / model.KF))
            eq = [Heq, Feq, model.m * Heq]
        end

        if NI < 1
            condition5 = model.e * model.m - model.theta * (model.muD - model.fD)
            Flim = (model.muD - model.fD) / (model.lambdaFWH * (model.e * model.m - model.theta * (model.muD - model.fD)))
            existence2Eq = (B > 0) & (Delta > 0) & ((condition5 < 0) | (2*A*Flim + B < 0))
            if existence2Eq
                Feq1 = -B / (2*A) - sqrt(Delta) / (2*A)
                Feq2 = -B / (2*A) + sqrt(Delta) / (2*A)

                
                Heq1 = (model.I) / (model.muD - model.fD - (model.e * model.lambdaFWH * model.m) / (1+model.theta * model.lambdaFWH * Feq1) * Feq1)
                Heq2 = (model.I) / (model.muD - model.fD - (model.e * model.lambdaFWH * model.m) / (1+model.theta * model.lambdaFWH * Feq2) * Feq2)

                eq = [[Heq1, Feq1, model.m * Heq1], [Heq2, Feq2, model.m * Heq2]]
            else
                @warn "Equilibrium EE^HFW computed while it does not exists ; infinite values return "
                Feq, Heq = Inf64, Inf64
                eq = [Heq, Feq, model.m * Heq]
            end
        end
    end
    return eq
end


function computeRootPF(model::modelHunterHT2)
    numA = (model.e * model.m - model.theta * (model.muD - model.fD + model.beta * model.m * model.I))
    A = model.rF / model.KF * numA
    B = -((1 - model.alpha) * model.rF * numA  + 
            (model.muD - model.fD + model.beta * model.m * model.I) * model.rF / (model.lambdaFWH * model.KF))
    C = ((model.muD - model.fD + model.m * model.beta * model.I) * (1 - model.alpha) * model.rF / model.lambdaFWH - model.m * model.I)

    PF = Polynomial([C, B, A])
    
    Feq = PolynomialRoots.roots(coeffs(PF))

    Feq1 = real(Feq[1])
    Feq2 = real(Feq[2])
    Heq1 = (model.I) / (model.muD - model.fD - (model.e * model.lambdaFWH * model.m) / (1+model.theta * model.lambdaFWH * Feq1) * Feq1)
    Heq2 = (model.I) / (model.muD - model.fD - (model.e * model.lambdaFWH * model.m) / (1+model.theta * model.lambdaFWH * Feq2) * Feq2)          


    return [[Heq1, Feq1], [Heq2, Feq2]]
end

function computeEigVal(model::modelHunterHT2, val::Vector{Float64})
    HD, FW = val[1], val[2]
    Jac = Matrix{Float64}(undef, 2, 2)
    Jac[1,1] = -(model.muD - model.fD) + model.e * model.m * model.lambdaFWH / (1 + model.lambdaFWH * model.theta * FW) * FW
    Jac[1,2] = model.e * model.m * model.lambdaFWH / (1 + model.lambdaFWH * model.theta * FW)^2 * HD
    Jac[2,1] = (-model.m * model.lambdaFWH / (1 + model.lambdaFWH * model.theta * FW) + 
                model.m * model.beta * (1 - model.alpha) * model.rF * (1 - FW / ((1 - model.alpha)*model.KF))) * FW
    Jac[2,2] = ((1 - model.alpha) * model.rF * (1 + model.beta * model.m * HD) * (1 - 2 * FW / ((1 - model.alpha)*model.KF)) -
                model.m * model.lambdaFWH / (1 + model.lambdaFWH * model.theta * FW)^2 * HD)

    return eigvals(Jac)

end

function computeMaxVal(model::modelHunterHT2)
    """
    Compute the bound for the invariant region Omega 
        {H_D + H_W + e F_W < Smax, F_W < Fmax, H_W < m_D/(m_D+m_W) Smax}
    """
    Fmax = model.KF * (1 - model.alpha)
    Smax = (1 + model.m) * (model.I + 
        (model.muD - model.fD + model.rF * (1-model.alpha) / 4) * model.e * model.KF * (1-model.alpha))
    Smax = Smax / ((model.muD - model.fD) / model.m - model.e * model.rF * (1-model.alpha)^2 * model.KF * model.beta / 4)
    
    Hwmax = model.mD / (model.mD + model.mW) * Smax
    
    return (Smax, Fmax, Hwmax)
end

